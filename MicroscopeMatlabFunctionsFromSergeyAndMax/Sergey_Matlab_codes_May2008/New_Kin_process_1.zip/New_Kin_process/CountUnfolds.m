function output = CountUnfolds(filenumber1, filenumberlast)
%This script will concatenate kinetics matrixes from files with numbers
%given by parameters, and make a histogram of how many times each molecule
%visited Low FRET state. 
%Later I will add a threshold for plotting only molecules that lived longer
%than certain time.
Kinetics=[];
for i=filenumber1:filenumberlast
    filename = strcat('(kinetics)cascade', num2str(i),'(4)','.dat');
    try
        tempdata = importdata(filename);
        Kinetics = [Kinetics;tempdata];
    catch
        ans = strcat('No file with ', filename, ' name')
    end
end
max = length(Kinetics);
UHist = [];
UnfoldCounter = 0;
for j=1:max    
    if Kinetics(j,1)~=9
        if Kinetics(j,1)==0
            UnfoldCounter = UnfoldCounter+1;
        else
        end
    else
        if Kinetics(j,2)==9
           UHist = [UHist;UnfoldCounter];
           UnfoldCounter = 0;
        else
        end
    end
end
hist(UHist)
outputfilename = strcat('UHist(',num2str(filenumber1),')(',num2str(filenumberlast),').dat');
fid = fopen(outputfilename,'w');
count = fprintf(fid,'%d\n',UHist);
fclose(fid);
        
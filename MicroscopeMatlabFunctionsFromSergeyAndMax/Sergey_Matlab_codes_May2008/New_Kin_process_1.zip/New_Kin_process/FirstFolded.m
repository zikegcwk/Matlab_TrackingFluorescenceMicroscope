function output = FirstFolded(filenumber1, filenumberlast)
%This script will concatenate kinetics matrixes from files with numbers
%given by parameters, and make a histogram of the times each molecule spent
%in first High FRET dwell. 

Kinetics=[];
for i=filenumber1:filenumberlast
    filename = strcat('(kinetics)cascade', num2str(i),'(4)','.dat');
    try
        tempdata = importdata(filename);
        Kinetics = [Kinetics;tempdata];
    catch
        ans = strcat('No file with ', filename, ' name')
    end
end
max = length(Kinetics);
FirstFoldedHist = [];
%UnfoldCounter = 0;
for j=1:max    
    if Kinetics(j,1)==9&&Kinetics(j,2)~=9
        if Kinetics(j+1,1)==3
            FirstFoldedHist = [FirstFoldedHist;Kinetics(j+1,2)];
        else
            if Kinetics(j+2,1)==3
            FirstFoldedHist = [FirstFoldedHist;Kinetics(j+2,2)];
            else
            end
        end
    end
end
hist(FirstFoldedHist)
outputfilename = strcat('FirstFoldedHist(',num2str(filenumber1),')(',num2str(filenumberlast),').dat');
fid = fopen(outputfilename,'w');
count = fprintf(fid,'%d\n',FirstFoldedHist);
fclose(fid);
        
function output = Select_Kin_Merge(start,stop,minlength,Keqav,width)
%width let's say 3-fold around average
%HURRRAAAAAY! It works!
MergedKin = [];
for i=start:stop
    getdatafrom = strcat('(kinetics)cascade', num2str(i), '(4).dat');
    try
        tempdata = importdata(getdatafrom);
        MergedKin = [MergedKin;tempdata];
    catch
        %barf = strcat('err')
    end
end
% length(MergedKin)
% return
Unfolded = [];
Folded = [];
UnfoldedTemp = [];
FoldedTemp = [];
TimeLow = 0;
TimeHigh = 0;
      for j=2:length(MergedKin)
                        
            if MergedKin(j,1)==0
%                 
                TimeLow = TimeLow + (isfinite(MergedKin(j,2))*MergedKin(j,2));
                UnfoldedTemp = [UnfoldedTemp;MergedKin(j,:)];
%                 isfinite(Kin(j,2))
%                 isfinite(Kin(j,3))
%                 return
            elseif MergedKin(j,1)==3
                TimeHigh = TimeHigh + (isfinite(MergedKin(j,2))*MergedKin(j,2));
                FoldedTemp = [FoldedTemp;MergedKin(j,:)];
            elseif MergedKin(j,1)==9&&MergedKin(j,2)==9
                Keq = TimeHigh/TimeLow;
                if (TimeLow+TimeHigh)>(1000*minlength/MergedKin(1,2))&&(Keq>(Keqav/width))&&(Keq<(Keqav*width))
                    
                    Unfolded = [Unfolded;UnfoldedTemp];
                    Folded = [Folded;FoldedTemp];
                    UnfoldedTemp = [];
                    FoldedTemp = [];
                    TimeLow = 0;
                    TimeHigh = 0;
                else
                    UnfoldedTemp = [];
                    FoldedTemp = [];
                    TimeLow = 0;
                    TimeHigh = 0;
                end
%                 
            else
            end
        
            
      end
parameters = strcat(num2str(minlength),'s_',num2str(log10(Keqav),2),'_',num2str(width));
newfilename1 = strcat('(merged',num2str(start),'to',num2str(stop),')Fkin(',parameters,').dat');%folding kinetcis
newfilename2 = strcat('(merged',num2str(start),'to',num2str(stop),')Ukin(',parameters,').dat');
dlmwrite(newfilename1, Unfolded,',');%Unfolded dwells-folding kinetics
dlmwrite(newfilename2, Folded,',');%Folded dwells - unfolding kinetics
